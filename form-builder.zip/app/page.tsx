"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FormBuilder } from "@/components/form-builder"

export default function HomePage() {
  const [showForm, setShowForm] = useState(false)

  if (showForm) {
    return <FormBuilder />
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4 text-balance">Form Builder</h1>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            Create dynamic forms with conditional logic, just like Google Forms
          </p>

          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Ready to build your form?</CardTitle>
              <CardDescription>Create forms with branching questions and conditional logic</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setShowForm(true)} size="lg" className="w-full">
                Start Building
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
