"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, FileText, CheckCircle, Loader2, AlertCircle } from "lucide-react"
import { FormQuestions } from "./form-questions"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface FormData {
  initialChoice: "new" | "existing" | ""
  responses: Record<string, any>
}

interface SubmissionState {
  isSubmitting: boolean
  error: string | null
  submissionId: string | null
}

export function FormBuilder() {
  const [currentStep, setCurrentStep] = useState<"home" | "initial" | "questions" | "complete">("home")
  const [formData, setFormData] = useState<FormData>({
    initialChoice: "",
    responses: {},
  })
  const [submission, setSubmission] = useState<SubmissionState>({
    isSubmitting: false,
    error: null,
    submissionId: null,
  })

  const handleBack = () => {
    if (currentStep === "initial") {
      setCurrentStep("home")
    } else if (currentStep === "questions") {
      setCurrentStep("initial")
    } else if (currentStep === "complete") {
      setCurrentStep("questions")
    }
  }

  const handleResponseChange = (questionId: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      responses: {
        ...prev.responses,
        [questionId]: value,
      },
    }))
  }

  const handleInitialChoiceChange = (choice: "new" | "existing") => {
    setFormData((prev) => ({
      ...prev,
      initialChoice: choice,
      responses: {}, // Reset responses when changing customer type
    }))
  }

  const handleSubmitSurvey = async () => {
    setSubmission((prev) => ({ ...prev, isSubmitting: true, error: null }))

    try {
      const response = await fetch("/api/submit-survey", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerType: formData.initialChoice,
          responses: formData.responses,
          submittedAt: new Date().toISOString(),
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Failed to submit survey")
      }

      setSubmission((prev) => ({
        ...prev,
        isSubmitting: false,
        submissionId: result.submissionId,
      }))

      setCurrentStep("complete")
    } catch (error) {
      setSubmission((prev) => ({
        ...prev,
        isSubmitting: false,
        error: error instanceof Error ? error.message : "An unexpected error occurred",
      }))
    }
  }

  const getProgressValue = () => {
    switch (currentStep) {
      case "home":
        return 0
      case "initial":
        return 25
      case "questions":
        return 75
      case "complete":
        return 100
      default:
        return 0
    }
  }

  const getRequiredQuestions = () => {
    if (formData.initialChoice === "new") {
      return ["hearAbout", "primaryInterest", "pricingImportance"]
    } else {
      return ["satisfaction", "customerDuration", "npsScore"]
    }
  }

  const isFormValid = () => {
    const required = getRequiredQuestions()
    return required.every((questionId) => {
      const value = formData.responses[questionId]
      return value !== undefined && value !== "" && value !== null
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            {currentStep !== "home" && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="flex items-center gap-2"
                disabled={submission.isSubmitting}
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            )}
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">Customer Feedback Survey</h1>
            </div>
          </div>

          {/* Progress Bar */}
          {currentStep !== "home" && (
            <div className="mb-8">
              <div className="flex justify-between text-sm text-muted-foreground mb-2">
                <span>Progress</span>
                <span>{getProgressValue()}% complete</span>
              </div>
              <Progress value={getProgressValue()} className="h-2" />
            </div>
          )}

          {/* Form Content */}
          <Card className="shadow-sm">
            <CardHeader className="bg-card border-b">
              <CardTitle className="text-xl">
                {currentStep === "complete" ? "Thank You!" : "Customer Feedback Survey"}
              </CardTitle>
              <p className="text-muted-foreground">
                {currentStep === "complete"
                  ? "Your feedback has been recorded successfully"
                  : "Help us improve our services by answering a few questions"}
              </p>
            </CardHeader>
            <CardContent className="p-6">
              {currentStep === "home" && (
                <div className="space-y-6">
                  <div className="text-center space-y-4">
                    <p className="text-foreground text-lg">Welcome to our feedback survey!</p>
                    <p className="text-muted-foreground">
                      This form uses conditional logic - you'll see different questions based on whether you're a new or
                      existing customer.
                    </p>
                  </div>
                  <Button onClick={() => setCurrentStep("initial")} className="w-full" size="lg">
                    Start Survey
                  </Button>
                </div>
              )}

              {currentStep === "initial" && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-foreground">What type of customer are you?</h3>
                    <p className="text-sm text-muted-foreground">This will determine which questions you see next</p>
                    <div className="space-y-3">
                      <label className="flex items-center space-x-3 cursor-pointer p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <input
                          type="radio"
                          name="customerType"
                          value="new"
                          checked={formData.initialChoice === "new"}
                          onChange={(e) => handleInitialChoiceChange(e.target.value as "new")}
                          className="h-4 w-4 text-primary"
                        />
                        <div>
                          <span className="text-foreground font-medium">New Customer</span>
                          <p className="text-sm text-muted-foreground">
                            I'm considering your services for the first time
                          </p>
                        </div>
                      </label>
                      <label className="flex items-center space-x-3 cursor-pointer p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <input
                          type="radio"
                          name="customerType"
                          value="existing"
                          checked={formData.initialChoice === "existing"}
                          onChange={(e) => handleInitialChoiceChange(e.target.value as "existing")}
                          className="h-4 w-4 text-primary"
                        />
                        <div>
                          <span className="text-foreground font-medium">Existing Customer</span>
                          <p className="text-sm text-muted-foreground">I'm already using your services</p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {formData.initialChoice && (
                    <div className="pt-4 border-t">
                      <Button onClick={() => setCurrentStep("questions")} className="w-full">
                        Continue to Questions
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {currentStep === "questions" && formData.initialChoice && (
                <div className="space-y-8">
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Customer Type:</strong>{" "}
                      {formData.initialChoice === "new" ? "New Customer" : "Existing Customer"}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">Questions marked with * are required</p>
                  </div>

                  {submission.error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{submission.error}</AlertDescription>
                    </Alert>
                  )}

                  <FormQuestions
                    customerType={formData.initialChoice}
                    responses={formData.responses}
                    onResponseChange={handleResponseChange}
                  />

                  <div className="pt-6 border-t">
                    <Button
                      onClick={handleSubmitSurvey}
                      className="w-full"
                      disabled={!isFormValid() || submission.isSubmitting}
                    >
                      {submission.isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : isFormValid() ? (
                        "Submit Survey"
                      ) : (
                        "Please complete required fields"
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {currentStep === "complete" && (
                <div className="text-center space-y-6">
                  <div className="flex justify-center">
                    <CheckCircle className="h-16 w-16 text-primary" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-foreground">Survey Completed!</h3>
                    <p className="text-muted-foreground">
                      Thank you for taking the time to provide your feedback. Your responses help us improve our
                      services.
                    </p>
                  </div>

                  <div className="bg-muted/50 p-4 rounded-lg text-left">
                    <h4 className="font-medium text-foreground mb-2">Submission Details:</h4>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      {submission.submissionId && (
                        <p>
                          <strong>Submission ID:</strong> {submission.submissionId}
                        </p>
                      )}
                      <p>
                        <strong>Customer Type:</strong>{" "}
                        {formData.initialChoice === "new" ? "New Customer" : "Existing Customer"}
                      </p>
                      <p>
                        <strong>Questions Answered:</strong> {Object.keys(formData.responses).length}
                      </p>
                      <p>
                        <strong>Submitted:</strong> {new Date().toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <Button
                    onClick={() => {
                      setCurrentStep("home")
                      setFormData({ initialChoice: "", responses: {} })
                      setSubmission({ isSubmitting: false, error: null, submissionId: null })
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Start New Survey
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
