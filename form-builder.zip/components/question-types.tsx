"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"

interface BaseQuestionProps {
  question: string
  description?: string
  required?: boolean
  value?: any
  onChange: (value: any) => void
}

export function TextQuestion({ question, description, required, value, onChange }: BaseQuestionProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium text-foreground">
              {question}
              {required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          <Input
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Your answer"
            className="max-w-md"
          />
        </div>
      </CardContent>
    </Card>
  )
}

export function TextAreaQuestion({ question, description, required, value, onChange }: BaseQuestionProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium text-foreground">
              {question}
              {required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          <Textarea
            value={value || ""}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Your detailed answer"
            rows={4}
            className="max-w-2xl"
          />
        </div>
      </CardContent>
    </Card>
  )
}

interface MultipleChoiceProps extends BaseQuestionProps {
  options: string[]
}

export function MultipleChoiceQuestion({
  question,
  description,
  required,
  options,
  value,
  onChange,
}: MultipleChoiceProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium text-foreground">
              {question}
              {required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          <RadioGroup value={value} onValueChange={onChange}>
            {options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="text-foreground cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      </CardContent>
    </Card>
  )
}

interface CheckboxQuestionProps extends BaseQuestionProps {
  options: string[]
}

export function CheckboxQuestion({
  question,
  description,
  required,
  options,
  value = [],
  onChange,
}: CheckboxQuestionProps) {
  const handleCheckboxChange = (option: string, checked: boolean) => {
    const currentValues = Array.isArray(value) ? value : []
    if (checked) {
      onChange([...currentValues, option])
    } else {
      onChange(currentValues.filter((v: string) => v !== option))
    }
  }

  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium text-foreground">
              {question}
              {required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          <div className="space-y-3">
            {options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Checkbox
                  id={`checkbox-${index}`}
                  checked={Array.isArray(value) && value.includes(option)}
                  onCheckedChange={(checked) => handleCheckboxChange(option, checked as boolean)}
                />
                <Label htmlFor={`checkbox-${index}`} className="text-foreground cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

interface RatingQuestionProps extends BaseQuestionProps {
  scale: number
  lowLabel?: string
  highLabel?: string
}

export function RatingQuestion({
  question,
  description,
  required,
  scale = 5,
  lowLabel = "Poor",
  highLabel = "Excellent",
  value,
  onChange,
}: RatingQuestionProps) {
  return (
    <Card className="border-l-4 border-l-primary">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <Label className="text-base font-medium text-foreground">
              {question}
              {required && <span className="text-destructive ml-1">*</span>}
            </Label>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>{lowLabel}</span>
              <span>{highLabel}</span>
            </div>
            <RadioGroup
              value={value?.toString()}
              onValueChange={(val) => onChange(Number.parseInt(val))}
              className="flex justify-between"
            >
              {Array.from({ length: scale }, (_, i) => i + 1).map((rating) => (
                <div key={rating} className="flex flex-col items-center space-y-2">
                  <RadioGroupItem value={rating.toString()} id={`rating-${rating}`} />
                  <Label htmlFor={`rating-${rating}`} className="text-sm text-muted-foreground cursor-pointer">
                    {rating}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
