"use client"

import {
  TextQuestion,
  TextAreaQuestion,
  MultipleChoiceQuestion,
  CheckboxQuestion,
  RatingQuestion,
} from "./question-types"

interface FormQuestionsProps {
  customerType: "new" | "existing"
  responses: Record<string, any>
  onResponseChange: (questionId: string, value: any) => void
}

export function FormQuestions({ customerType, responses, onResponseChange }: FormQuestionsProps) {
  if (customerType === "new") {
    return (
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-foreground mb-4">New Customer Questions</h2>

        <TextQuestion
          question="How did you hear about us?"
          description="Please tell us where you first learned about our company"
          required
          value={responses.hearAbout}
          onChange={(value) => onResponseChange("hearAbout", value)}
        />

        <MultipleChoiceQuestion
          question="What is your primary interest?"
          description="Select the main reason you're considering our services"
          required
          options={[
            "Product Quality",
            "Competitive Pricing",
            "Customer Service",
            "Brand Reputation",
            "Recommendation from friend",
          ]}
          value={responses.primaryInterest}
          onChange={(value) => onResponseChange("primaryInterest", value)}
        />

        <CheckboxQuestion
          question="Which services are you interested in?"
          description="Select all that apply"
          options={[
            "Basic Package",
            "Premium Package",
            "Enterprise Solution",
            "Consulting Services",
            "Technical Support",
          ]}
          value={responses.interestedServices}
          onChange={(value) => onResponseChange("interestedServices", value)}
        />

        <RatingQuestion
          question="How important is pricing in your decision?"
          description="Rate from 1 (not important) to 5 (very important)"
          scale={5}
          lowLabel="Not Important"
          highLabel="Very Important"
          value={responses.pricingImportance}
          onChange={(value) => onResponseChange("pricingImportance", value)}
        />

        <TextAreaQuestion
          question="What questions do you have about our services?"
          description="Please share any specific questions or concerns"
          value={responses.questions}
          onChange={(value) => onResponseChange("questions", value)}
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-foreground mb-4">Existing Customer Questions</h2>

      <RatingQuestion
        question="How satisfied are you with our current service?"
        description="Rate your overall satisfaction"
        scale={5}
        lowLabel="Very Dissatisfied"
        highLabel="Very Satisfied"
        required
        value={responses.satisfaction}
        onChange={(value) => onResponseChange("satisfaction", value)}
      />

      <MultipleChoiceQuestion
        question="How long have you been our customer?"
        required
        options={["Less than 6 months", "6 months - 1 year", "1-2 years", "2-5 years", "More than 5 years"]}
        value={responses.customerDuration}
        onChange={(value) => onResponseChange("customerDuration", value)}
      />

      <CheckboxQuestion
        question="Which aspects of our service do you value most?"
        description="Select all that apply"
        options={["Reliability", "Customer Support", "Value for Money", "Product Quality", "Ease of Use", "Innovation"]}
        value={responses.valuedAspects}
        onChange={(value) => onResponseChange("valuedAspects", value)}
      />

      <TextAreaQuestion
        question="What improvements would you like to see?"
        description="Please share your suggestions for how we can better serve you"
        value={responses.improvements}
        onChange={(value) => onResponseChange("improvements", value)}
      />

      <RatingQuestion
        question="How likely are you to recommend us to others?"
        description="Net Promoter Score (0 = not likely, 10 = extremely likely)"
        scale={10}
        lowLabel="Not Likely"
        highLabel="Extremely Likely"
        required
        value={responses.npsScore}
        onChange={(value) => onResponseChange("npsScore", value)}
      />

      <TextQuestion
        question="What is the main reason for your score above?"
        description="Help us understand your rating"
        value={responses.npsReason}
        onChange={(value) => onResponseChange("npsReason", value)}
      />
    </div>
  )
}
